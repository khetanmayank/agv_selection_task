/*By:

     MAYANK KHETAN
     15CS10028
     Implementing Dijkstra

*/
#include "opencv2/core/core.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#include "ros/ros.h"
#include "std_msgs/String.h"
#include "geometry_msgs/Point.h"
#include <sstream>

#define inf 100000000
#define fori(a,b) for(int i=a;i<=b;i++)
#define forj(a,b) for(int j=a;j<=b;j++)


using namespace std;
using namespace cv;

void pathCallback(const geometry_msgs::Point::ConstPtr& msg)
{
Mat img=imread("/home/mayank/agv/src/agv_task1/output_image/ps1.png",1);
int X=(int)(msg->x);int Y=(int)(msg->y);
img.at<Vec3b>(X,Y)[0]=255;
img.at<Vec3b>(X,Y)[1]=0;
img.at<Vec3b>(X,Y)[2]=0;
imwrite("/home/mayank/agv/src/agv_task1/output_image/ps1.png",img);
imshow("shortest_path",img);
waitKey(10);

ROS_INFO("I heard: [%lf,%lf,%lf]", msg->x,msg->y,msg->z);
}

int main(int argc,char **argv)
{
ros::init(argc,argv,"path_marker");
ros::NodeHandle n;
ros::Subscriber path_sub=n.subscribe("path",1000,pathCallback);
ros::spin();
return 0;
}
