/*By:

     MAYANK KHETAN
     15CS10028
     Implementing Dijkstra

*/

#include "opencv2/core/core.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#include "ros/ros.h"
#include "std_msgs/String.h"
#include "geometry_msgs/Point.h"
#include <sstream>

#define inf 100000000
#define fori(a,b) for(int i=a;i<=b;i++)
#define forj(a,b) for(int j=a;j<=b;j++)


using namespace std;
using namespace cv;

struct point{long long int x;long long int y;};

int mark[300][300];
double Distance[300][300];
point parent[300][300];

bool withinmatrix(int a,int b,Mat image)
{
if(a>=0 && b>=0 && a<image.rows && b<image.cols)
return true;
return false;
}

void path(Mat image,point End)
{
int Min,X,Y;
double dist,distadd;
point minpoint;
while(1)
{
Min=inf;
fori(0,image.rows-1)
forj(0,image.cols-1)
if(mark[i][j]==0 && Distance[i][j]<Min)
{
Min=Distance[i][j];
minpoint.x=i;minpoint.y=j;
}
X=minpoint.x;
Y=minpoint.y;
mark[X][Y]=1;
if(mark[End.x][End.y]==1)
return ;
dist=Distance[X][Y];
fori(-1,1)
forj(-1,1)
{
if(withinmatrix(X+i,Y+j,image))
{
distadd=sqrt(abs(i)+abs(j));
if(mark[X+i][Y+j]==0 && Distance[X+i][Y+j]>(dist+distadd) && !(image.at<Vec3b>(X+i,Y+j)[0]>=200 && image.at<Vec3b>(X+i,Y+j)[1]>=200 && image.at<Vec3b>(X+i,Y+j)[2]>=200))
{
Distance[X+i][Y+j]=dist+distadd;
parent[X+i][Y+j]=minpoint;
}
}
}
}
}

int main(int argc,char **argv)
{
Mat image =imread("/home/mayank/agv/src/agv_task1/input_image/ps1.png",1);
point start ={0,0};
point End ={0,0};
long long int countg=0,countr=0;
fori(0,image.rows-1)
forj(0,image.cols-1)
{
if(image.at<Vec3b>(i,j)[0]<50 && image.at<Vec3b>(i,j)[1]>200 && image.at<Vec3b>(i,j)[2]<50)
{countg++;start.x+=i;start.y+=j;}
if(image.at<Vec3b>(i,j)[0]<50 && image.at<Vec3b>(i,j)[1]<50 && image.at<Vec3b>(i,j)[2]>200)
{countr++;End.x+=i;End.y+=j;}
}
start.x=start.x/countg;
start.y=start.y/countg;
End.x=End.x/countr;
End.y=End.y/countr;
//start ={28,30};
//End ={162,170};
fori(0,image.rows-1)
forj(0,image.cols-1)
{
mark[i][j]=0;
Distance[i][j]=inf;
}
Distance[start.x][start.y]=0;
parent[start.x][start.y]=start;
path(image,End);
imshow("initial_image",image);
//Mat image_2=image.clone();
point st=End;

ros::init(argc,argv,"path_planner");
ros::NodeHandle n;
ros::Publisher path_pub=n.advertise<geometry_msgs::Point>("path",1000);
ros::Rate loop_rate(10);
while(ros::ok())
{
geometry_msgs::Point msg;

while(!(parent[st.x][st.y].x==st.x && parent[st.x][st.y].y ==st.y))
{

msg.x=st.x;
msg.y=st.y;
msg.z=0;

ROS_INFO("%lf %lf %lf",msg.x,msg.y,msg.z);
path_pub.publish(msg);
ros::spinOnce();
loop_rate.sleep();

/*image_2.at<Vec3b>(st.x,st.y)[0]=255;image_2.at<Vec3b>(st.x,st.y)[1]=0;image_2.at<Vec3b>(st.x,st.y)[2]=0;*/

st=parent[st.x][st.y];
}
}
waitKey(0);
}
